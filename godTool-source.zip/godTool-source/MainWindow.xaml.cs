﻿using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;
using Gma.System.MouseKeyHook;
using FuzzySharp;
using System.Linq;



namespace WpfApp1
{
    public class AppConfig
    {
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Key { get; set; }
    }
    public class allTitles
    {
        public List<AppConfig>? AllTitle { get; set; }
    }



    public partial class MainWindow : Window
    {
        private IntPtr _windowHandle;
        private IKeyboardMouseEvents _globalHook;
        private DispatcherTimer _mousePollTimer;
        private bool _isMouseInside = false;
        private bool isLocal = true;

        public MainWindow()
        {
            InitializeComponent();
            SubscribeToGlobalHook();
        }
        //----------------------------------------------------------------------------
        private static class NativeMethods
        {
  
            [DllImport("user32.dll")]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool GetCursorPos(out POINT lpPoint);

            [DllImport("user32.dll")]
            [return: MarshalAs(UnmanagedType.Bool)]
            public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }


        private void MousePollTimer_Tick(object sender, EventArgs e)
        {
            if (_windowHandle == IntPtr.Zero || this.WindowState == WindowState.Minimized)
                return;

          
            if (!NativeMethods.GetCursorPos(out POINT mousePos))
                return;

            if (!NativeMethods.GetWindowRect(_windowHandle, out RECT windowRect))
                return;

            bool isInsideNow = mousePos.X >= windowRect.Left && mousePos.X < windowRect.Right &&
                               mousePos.Y >= windowRect.Top && mousePos.Y < windowRect.Bottom;

            
            if (isInsideNow && !_isMouseInside && isLocal)
            {
                
                this.Opacity = 0.1;
                _isMouseInside = true;
                Debug.WriteLine("Mouse ENTERED. Opacity -> 0.1");
            }
            else if (!isInsideNow && _isMouseInside && isLocal)
            {
               
                this.Opacity = 0.0;
                _isMouseInside = false;
                Debug.WriteLine("Mouse LEFT. Opacity -> 0.0");
            }
        }
        //----------------------------------------------------------------------------
        private void SubscribeToGlobalHook()
        {

            _globalHook = Hook.GlobalEvents();


            _globalHook.KeyDown += GlobalHook_KeyDown;

        }
        private void GlobalHook_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
           

            Debug.WriteLine($"[Global Hook] KeyDown: {e.KeyCode}");


            if (e.KeyCode == System.Windows.Forms.Keys.F2)
            {
                Application.Current.Dispatcher.Invoke(() =>
                {
     
                    if (isLocal)
                    {
                        this.Opacity = 0.0;
                        isLocal = false;
                        Debug.WriteLine("[Global Hook] Window made transparent.");
                    }
                    else
                    {
                        this.Opacity = 0.1;
                        isLocal = true;
                        Debug.WriteLine("[Global Hook] Window made visible.");
                    }
                });
            }
        }




        [DllImport("user32.dll", SetLastError = true)] 
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);



        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool SetWindowDisplayAffinity(IntPtr hWnd, uint dwAffinity);


        private static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);

        private static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);

        private const uint SWP_NOSIZE = 0x0001;

        private const uint SWP_NOMOVE = 0x0002;



        public const uint WDA_NONE = 0x00000000;
        public const uint WDA_EXCLUDEFROMCAPTURE = 0x00000011; 



        private DispatcherTimer _topmostTimer;


        protected override void OnSourceInitialized(EventArgs e)

        {
            base.OnSourceInitialized(e);

            _windowHandle = new WindowInteropHelper(this).Handle;
            if (_windowHandle == IntPtr.Zero)
            {
                MessageBox.Show("无法获取窗口句柄。");
                return;
            }

            _topmostTimer = new DispatcherTimer();

            _topmostTimer.Interval = TimeSpan.FromSeconds(1);

            _topmostTimer.Tick += TopmostTimer_Tick;

            _topmostTimer.Start();

            _mousePollTimer = new DispatcherTimer();
            _mousePollTimer.Interval = TimeSpan.FromMilliseconds(100);
            _mousePollTimer.Tick += MousePollTimer_Tick;
            _mousePollTimer.Start();

        }

        private void TopmostTimer_Tick(object sender, EventArgs e)

        {

            if (this.WindowState == WindowState.Minimized || _windowHandle == IntPtr.Zero)

            {
                return;
            }
            SetWindowPos(_windowHandle, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
            SetWindowDisplayAffinity(_windowHandle, WDA_EXCLUDEFROMCAPTURE);

        }


        private void ForceTopmostCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            _topmostTimer?.Start();
        }
        private void ForceTopmostCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {


            if (_windowHandle != IntPtr.Zero)
            {
                SetWindowPos(_windowHandle, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
                SetWindowDisplayAffinity(_windowHandle, WDA_NONE);

            }
        } 

        protected override void OnClosing(CancelEventArgs e)

        {

            base.OnClosing(e);

            _topmostTimer?.Stop();
            _mousePollTimer?.Stop();
            _mousePollTimer = null;

            if (_globalHook != null)
            {
                _globalHook.KeyDown -= GlobalHook_KeyDown; 
                _globalHook.Dispose();                    
            }



            if (_windowHandle != IntPtr.Zero)

            {

                SetWindowDisplayAffinity(_windowHandle, WDA_NONE);

                _windowHandle = IntPtr.Zero; 

            }
        }
        private void DragBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
                if (_windowHandle != IntPtr.Zero)
                {
                    Debug.WriteLine("DragMove finished. Re-applying protection.");
                    SetWindowPos(_windowHandle, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
                    SetWindowDisplayAffinity(_windowHandle, WDA_EXCLUDEFROMCAPTURE);
                }
            }
        }

        private string jsonPath;
        private allTitles? myData;
        private void SelectJsonFile_Click(object sender, RoutedEventArgs e)
        {

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "JSON 文件 (*.json)|*.json|所有文件 (*.*)|*.*";
            openFileDialog.Title = "请选择一个 JSON 文件";
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            if (openFileDialog.ShowDialog() == true)
            {

                string selectedFilePath = openFileDialog.FileName;

                jsonPath = selectedFilePath;
            }
            ReadJsonFile_Click(sender,e);
        }
        private void ReadJsonFile_Click(object sender, RoutedEventArgs e)
        {

            string filePath = jsonPath;


            if (string.IsNullOrEmpty(filePath))
            {
                MessageBox.Show("请先选择一个 JSON 文件。");
                return;
            }

            if (!File.Exists(filePath))
            {
                MessageBox.Show($"错误：文件未找到。\n路径: {filePath}");
                return;
            }

            try
            {

                string jsonString = File.ReadAllText(filePath);

           
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };

              
                myData = JsonSerializer.Deserialize<allTitles>(jsonString, options);

              
                if (myData != null && myData.AllTitle != null)
                {

                    ResultsGrid.ItemsSource = myData.AllTitle;


                    if (myData.AllTitle.Count == 0)
                    {
                        MessageBox.Show("JSON 加载成功，但配置列表(AllTitle)为空。");
                    }
                }
                else
                {

                    ResultsGrid.ItemsSource = null;
                    MessageBox.Show("JSON 文件内容为空或格式不正确。");
                }
            }
            catch (JsonException jsonEx)
            {

                MessageBox.Show($"JSON 解析失败: {jsonEx.Message}");
            }
            catch (Exception ex)
            {
        
                MessageBox.Show($"读取文件时发生未知错误: {ex.Message}");
            }
        }
        private List<AppConfig> _fullDataList;

        private void title_search(object sender, RoutedEventArgs e)
        {
            string input = titleContent.Text;
            int cutoff = 70; 

            if (myData.AllTitle != null && !string.IsNullOrEmpty(input))
            {
   
                _fullDataList = myData.AllTitle;

                var titleChoices = _fullDataList.Select(item => item.Title);


                
                var fuzzyResults = FuzzySharp.Process.ExtractAll(input, titleChoices, processor: s => s.ToLower(), cutoff: cutoff);

  
                var matchedTitles = fuzzyResults.Select(r => r.Value).ToHashSet();

            
                var filteredList = _fullDataList.Where(item => matchedTitles.Contains(item.Title)).ToList();

                ResultsGrid.ItemsSource = filteredList;
            }
            else
            {
  
                ResultsGrid.ItemsSource = myData.AllTitle;
            }
        }
        //------------------------------------------------------------------
        private void Window_Deactivated(object sender, EventArgs e)
        {

            Dispatcher.BeginInvoke(new Action(() =>
            {
                this.Topmost = false;
                this.Topmost = true;
            }), System.Windows.Threading.DispatcherPriority.ApplicationIdle);
        }


    }
    }